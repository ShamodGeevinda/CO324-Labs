# E/18/397

from urllib import request, response
from urllib.error import HTTPError
from urllib.error import URLError

def get_HTTP_response_code(url:str) -> int:
	"""Returns the HTTP response code"""
	response = request.urlopen(url)
	return response.getcode()



def get_hosted_server(url:str) -> str:
	"""Return the server used to host the given site"""
	response = request.urlopen(url)
	txt = response.getheader("Server").split()
	return txt[0]
	
	


def get_hosted_OS(url:str) -> str:
	"""Return the OS used to host the given site"""
	response = request.urlopen(url)
	txt = response.getheader("Server").split()
	return txt[1][1:-1]


def is_http_streaming(url:str) -> bool:

	"""Returns True or False based on http streaming"""

	response = request.urlopen(url)
	if(response.getheader("Transfer-Encoding") == "chunked"):
		return True
	else:
		return False
	
	


def is_valid_url(url:str) -> str:

	try:
		response = request.urlopen(url)
		return "Valid"
	except URLError as e:
		return "Invalid:" + str(e)

"""
	For valid URLs:
		Returns the string 'Valid'
	For invalid URLs:
		Returns 'Invalid:' + <error msg of error thrown by the urllib.request module>
	"""



def read_response(url:str) -> bytes:
	"""Returns the response body"""
	bytesBody = request.urlopen(url).read()
	return  bytesBody

def decode_response_body(body:bytes) -> str:
	"""Returns the decoded response body"""
	return (str( body, 'utf-8' ))
	


if __name__ == "__main__":
	# Q1.a
	http_code = get_HTTP_response_code("http://eng.pdn.ac.lk")
	print(http_code)
	# Add your code to test locally
	
	# Q1.b
	server = get_hosted_server("http://eng.pdn.ac.lk")
	print(server)
	# Add your code to test locally

	# Q1.c
	os = get_hosted_OS("http://eng.pdn.ac.lk")
	print(os)
	# # Add your code to test locally

	# # Q1.d
	# apple_site_response = is_http_streaming("https://www.apple.com/")
	# eng_site_reponse = is_http_streaming("http://eng.pdn.ac.lk")
	# print(apple_site_response)
	# print(eng_site_reponse)
	# # Add your code to test locally

	# # Q1.e
	# first_url_validity = is_valid_url("http://eng.pdn.ac.lk")
	# second_url_validity = is_valid_url("http://eng.pdn.ac.lk/unknown")
	# third_url_validity = is_valid_url("http://unknown.pdn.ac.lk")
	# print(first_url_validity)
	# print(second_url_validity)
	# print(third_url_validity)
	# # Add your code to test locally	

	# # Q1.f
	# eng_site_body = read_response("http://eng.pdn.ac.lk")
	# print(eng_site_body)
	# print(type(eng_site_body))
	# # Add your code to test locally	
	
	# # Q1.g
	# decoded_body = decode_response_body(eng_site_body)
	# print(decoded_body)
	# Add your code to test locally