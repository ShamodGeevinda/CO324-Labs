# Q1
## Q1.a
Get the HTTP response code for querying a given URL

```python
def get_HTTP_response_code(url:str) -> int:
	"""Returns the HTTP response code"""
```

## Q1.b
Get the web server used to host the given site

```python
def get_hosted_server(url:str) -> str:
	"""Return the server used to host the given site"""
```

## Q1.c
Get the Operating System (OS) used to host the given site

```python
def get_hosted_OS(url:str) -> str:
	"""Return the OS used to host the given site"""
```

## Q1.d
When working with the web, we encounter static content and dynamically generated content. In the case of dynamic content, we might not know the size of the content to be transferred beforehand. HTTP streaming is one such technique to handle scenarios like that. Read more on HTTP streaming referring to the following.
* [HTTP Streaming](https://www.pubnub.com/learn/glossary/what-is-http-streaming/)
* [Relation between HTTP Streaming and HTTP Headers](https://gist.github.com/CMCDragonkai/6bfade6431e9ffb7fe88)

Based on HTTP headers return whether a given URL uses HTTP streaming or not. **Hint:** Look at HTTP header fields present in the scenario of streaming. You might need to consider the case (sometimes the first letter of some fields is capitalized).
```python
def is_http_streaming(url:str) -> bool:
	"""Returns True or False based on http streaming"""
	pass #TODO
```

## Q1.e
All questions up to part d assumed that URLs were correct. In reality, it may not be true. Queried resources may not be available. Queried servers may be overloaded, or face internal crashes upon requests. Hence, as software developers, we must handle such scenarios. Errors thrown by the request module are provided here. 
* [Errors - Request library](https://docs.python.org/3/library/urllib.error.html)

To catch errors and exceptions thrown by a piece of code, we could use `try-except-finally` in python. You can use the given link as a reference.
* [Error handling - try-except-finally](https://docs.python.org/3/tutorial/errors.html)

Based on the errors thrown by the request module, complete the following function.
```python
def is_valid_url(url:str) -> str:
	"""
	For valid URLs:
		Returns the string 'Valid'
	For invalid URLs:
		Returns 'Invalid:' + <error msg of error thrown by the urllib.request module>
	"""
	pass #TODO
```


## Q1.f
For a given URL, extract the response body by reading the HTTP Response.

```python
def read_response(url:str) -> bytes:
	"""Returns the response body"""
	pass #TODO
```

## Q1.g
Print the output from Q1.f. You may observe that the output is not easily readable (it is encoded). Decode this encoded output completing the function given below. **Hint:** Look at the charset field in the response header to get the correct decoding format.
```python
def decode_response_body(body:bytes) -> str:
	"""Returns the decoded response body"""
	pass #TODO
```