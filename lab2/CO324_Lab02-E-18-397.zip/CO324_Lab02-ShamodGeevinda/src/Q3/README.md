# Q3

Use Duck Duck Go (DDG) search engine for this question.

## Q3.a

Get the `top n` number of URLs for a given search term. Complete the following function. **Hint:** Look at the Results and RelatedTopics of the response to create a list of URLs.
```python
def get_top_n_urls(search_term:str, n: int) -> List[str]:
	"""Extract top n number of URLs from the response"""
	pass #TODO
```

For example, `get_top_n_urls('University of Peradeniya', 1)` should return `["http://www.pdn.ac.lk"]`

## Q3.b

Get the metadata for a given list of URLs. Complete the following function. **Hint:** You can use `response.headers.items()` to get the HTTP headers as a list of tuples.
```python
def get_metadata(urls:List[str]) -> List[List[tuple]]:
	"""Returns a list of the HTTP headers for each URL in urls list"""
	pass #TODO
```

For example, `get_metadata(["http://www.pdn.ac.lk"])` should return `[[('Date', 'date_query_is_performed'), ('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Content-Type-Options', 'nosniff'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8')]]`.

## Q3.c

Get the HTTP headers without downloading the response body. Use the appropriate HTTP method.
* [HTTP Methods](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods)

Add the used HTTP method to the headers as a tuple in the format ('method', 'HTTP_method'). 
```python
def get_headers_only(url: str) -> List[tuple]:
	"""
		Returns the HTTP headers with the HTTP method used without 
		downloading the response body
	"""
	pass #TODO
```

For example, `get_headers_only("http://www.pdn.ac.lk")` should return <code>[('Date', 'date_query_is_performed'), ('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Content-Type-Options', 'nosniff'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8'), **('method', 'http_method_used')**] </code>