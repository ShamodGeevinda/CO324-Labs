# E/18/397

from urllib import request
import json
from typing import List
import requests

def get_top_n_urls(search_term:str, n: int) -> List[str]:
	"""Extract top n number of URLs from the response"""
	search_entry = search_term.strip().split(" ") #seperate input words by spaces
	req_type = "+".join(search_entry) #connect input words by '+' for the query
	response = request.urlopen(f"https://www.duckduckgo.com/?q={req_type}&format=json&pretty=1") #make a request
	
	body = json.loads(response.read().decode("utf-8"))  #store response in json format
	# print(body)
	results = []    #to store results
	related_topics = [] 

	if n > 0:   #if valid int for number of result is given extract urls in 2 loops
		for item in body['Results']: 
			results.append(item['FirstURL'])

		for item in body['RelatedTopics']:
			related_topics.append(item['FirstURL'])        
         
		total = results + related_topics #get total results
            
		if(n > len(total)):    #if number of results is larger than total result size return whole results
			return total

		response.close() #close used resources 

		return (total[ :n])    #else return requested url list
	return [] #for invalid number of results return empty list


def get_metadata(urls:List[str]) -> List[List[tuple]]:
	"""Returns a list of the HTTP headers for each URL in urls list"""
	http_headers = [] #store results

	for URL in urls:
		try:  #use a loop to retrieve headers from urls and append to a list
			response = request.urlopen(URL)
			http_headers.append(response.headers.items())
		except:
			pass
		
	# response.close() #close used resources
	return http_headers  #return the list


def get_headers_only(url: str) -> List[tuple]:
	"""
		Returns the HTTP headers with the HTTP method used without 
		downloading the response body
	"""
	http_headers = []

	
	response = request.urlopen(url)
	http_headers.append((requests.head(url)).headers)
	# http_headers.append(response.headers.items())  
	http_headers.append(("method", response._method)) 
	

	# response.close()    #close used resources
	return http_headers #return list


if __name__ == "__main__":
	#Q3.a
	top_n_urls = get_top_n_urls("University of Peradeniya", 6)
	print(top_n_urls)
	# Add your code to test locally

	#Q3.b
	# metadata = get_metadata(["http://www.pdn.ac.lk/"])
	# print(metadata)
	# Add your code to test locally

	#Q3.c
	metadata_with_method = get_headers_only("http://www.pdn.ac.lk/")
	print(metadata_with_method)
	# Add your code to test locally

