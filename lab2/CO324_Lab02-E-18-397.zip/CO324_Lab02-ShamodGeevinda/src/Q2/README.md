# Q2
## Q2.a

We will be using the **Duck Duck Go (DDG)** search engine for this question. URL parameters (or query strings) help to query information more effectively. For example, we can use URL parameters to get the search results using the DDG.

Query parameters start with a Question Mark *(?)* followed by a set of key-value pairs. In the URL given below, `q=University+of+Peradeniya` is such a key-value pair. We can use this `q=` parameter to get the search results using the DDG. The term we are searching for is *"University of Peradeniya"*

`"https://www.duckduckgo.com/?q=University+of+Peradeniya"`

You can read more about URL parameters and how it affects SEO using the below link.

* [URL Parameters](https://www.semrush.com/blog/url-parameters/)


If you run the given `Q2_lab02.py` script, you may observe that the output cannot be read easily. Your task is to return the output using the *JSON format* and in a *more readable manner*.

Modify the given function to use the URL parameters. **Hint:** Look at the `format` and the `pretty` URL parameters.

```python
def add_url_parameters():
	"""
		Modify the URL using url parameters
		
		1) Set format to json
		2) Set output to an easily readable format
		3) Return the modified URL
	"""
```


## Q2.b

Search your name in Sinhala/Tamil using the DDG. Modify the function given below. **Hint:** Check how you can add unicode/non-ASCII characters to a URL.

Use the following link to type your name in Sinhala/Tamil.
* [Online Keyboard](https://www.lexilogos.com/keyboard/)

```python
def search_name_in_sinhala_or_tamil():
	"""Returns the response and the url after searching name in sinhala/tamil"""
```