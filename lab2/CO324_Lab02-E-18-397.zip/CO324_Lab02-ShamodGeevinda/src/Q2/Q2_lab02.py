# E/18/397

from urllib import request, parse
from json import dumps, loads

def add_url_parameters() -> str:
	"""
		Modify the URL using url parameters
		
		1) Set format to json
		2) Set output to an easily readable format
		3) Return the modified URL
	"""
	# TODO: Modify the url below
	modified_url = "https://www.duckduckgo.com/?q=University+of+Peradeniya&format=json&pretty=1"
	return modified_url


def search_name_in_sinhala_or_tamil():
	"""Returns the response and the url after searching name in sinhala/tamil"""
	url = "https://duckduckgo.com/?q=" + parse.quote("ෂමොද්+ගීවින්ද")  #TODO: Edit this line
	with request.urlopen(url) as query:
		body = query.read()
		body = body.decode("UTF-8")
		return body, url
		

if __name__ == "__main__":
	# Q2.a
	url = add_url_parameters()
	with request.urlopen(url) as query:
		body = query.read().decode("UTF-8")
		# print(body)
		print(dumps(loads(body), indent=4)) # Uncomment this line once Q2.a is complete

	#Q2.b
	response, url = search_name_in_sinhala_or_tamil()
	print("Response:\n"+response)
	print("url:"+url)

	# Add your code to test locally