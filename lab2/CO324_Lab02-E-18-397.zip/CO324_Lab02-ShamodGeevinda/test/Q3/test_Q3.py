import sys
from urllib import request
from typing import List
sys.path.append('./src/Q3')

from Q3_lab02 import *


def test_get_top_n_urls():
    assert get_top_n_urls('University of Peradeniya', 1) == ["https://www.pdn.ac.lk"]
    assert len(get_top_n_urls('University of Peradeniya', 1)) == 1
    assert type(get_top_n_urls('University of Peradeniya', 1)) == list

    assert get_top_n_urls('University of Peradeniya', 3) == ['https://www.pdn.ac.lk', 'https://duckduckgo.com/c/University_of_Peradeniya', 'https://duckduckgo.com/Education_in_Sri_Lanka']
    assert len(get_top_n_urls('University of Peradeniya', 3)) == 3
    assert type(get_top_n_urls('University of Peradeniya', 3)) == list

    assert get_top_n_urls('University of Colombo', 1) == ["http://www.cmb.ac.lk"]
    assert len(get_top_n_urls('University of Colombo', 1)) == 1
    assert type(get_top_n_urls('University of Colombo', 1)) == list

    assert get_top_n_urls('University of Colombo', 4) == ['http://www.cmb.ac.lk', 'https://duckduckgo.com/c/University_of_Colombo', 'https://duckduckgo.com/c/Statutory_boards_of_Sri_Lanka', 'https://duckduckgo.com/c/Universities_in_Sri_Lanka']
    assert len(get_top_n_urls('University of Colombo', 4)) == 4
    assert type(get_top_n_urls('University of Colombo', 4)) == list

    assert get_top_n_urls('Valley Forge National Park', 2) == ["https://www.nps.gov/vafo/", "https://duckduckgo.com/c/Valley_Forge_National_Historical_Park"]
    assert len(get_top_n_urls('Valley Forge National Park', 2)) == 2
    assert type(get_top_n_urls('Valley Forge National Park', 2)) == list


def test_get_metadata():
    assert get_metadata(["http://www.pdn.ac.lk"])[0][1:] == [('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Content-Type-Options', 'nosniff'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8')]
    assert len(get_metadata(["http://www.pdn.ac.lk"])) == 1
    assert type(get_metadata(["http://www.pdn.ac.lk"])) == list

    assert get_metadata(["https://arts.pdn.ac.lk/ ", "http://www.eng.ruh.ac.lk/"])[0][1:] == [('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8')]
    assert get_metadata(["https://arts.pdn.ac.lk/ ", "http://www.eng.ruh.ac.lk/"])[1][1:] == [('Server', 'Apache/2.4.18 (Ubuntu)'), ('Vary', 'Accept-Encoding'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8')]
    assert len(get_metadata(["https://arts.pdn.ac.lk/ ", "http://www.eng.ruh.ac.lk/"])) == 2
    assert type(get_metadata(["https://arts.pdn.ac.lk/ ", "http://www.eng.ruh.ac.lk/"])) == list


def test_get_headers_only():
    assert get_headers_only("http://www.pdn.ac.lk/")[1:] == [('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Content-Type-Options', 'nosniff'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8'), ('method', 'HEAD')]
    assert get_headers_only("https://arts.pdn.ac.lk/ ")[1:] == [('Server', 'Apache/2.4.46 (FreeBSD) OpenSSL/1.0.2s-freebsd PHP/7.1.33'), ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'SAMEORIGIN'), ('X-Powered-By', 'PHP/7.1.33'), ('X-XSS-Protection', '1; mode=block'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8'), ('method', 'HEAD')]
    assert get_headers_only("http://www.eng.ruh.ac.lk/")[1:] == [('Server', 'Apache/2.4.18 (Ubuntu)'), ('Vary', 'Accept-Encoding'), ('Connection', 'close'), ('Transfer-Encoding', 'chunked'), ('Content-Type', 'text/html; charset=UTF-8'), ('method', 'HEAD')]

    