import sys
import codecs

sys.path.append('./src/Q1')

from Q1_lab02 import *

def test_get_HTTP_response_code():
	assert get_HTTP_response_code("http://eng.pdn.ac.lk") == 200
	assert type(get_HTTP_response_code("http://eng.pdn.ac.lk")) == int

	assert get_HTTP_response_code("https://www.google.com") == 200
	assert type(get_HTTP_response_code("https://www.google.com")) == int


def test_get_hosted_server():
	assert get_hosted_server("http://eng.pdn.ac.lk") == "Apache/2.4.35"
	assert type(get_hosted_server("http://eng.pdn.ac.lk")) == str

	assert get_hosted_server("https://arts.pdn.ac.lk/ ") == "Apache/2.4.46"
	assert type(get_hosted_server("https://arts.pdn.ac.lk/ ")) == str

	assert get_hosted_server("http://www.eng.ruh.ac.lk/") == "Apache/2.4.18"
	assert type(get_hosted_server("http://www.eng.ruh.ac.lk/")) == str

	assert get_hosted_server("http://www.jfn.ac.lk/") == "Apache/2.4.6"
	assert type(get_hosted_server("http://www.jfn.ac.lk/")) == str

	assert get_hosted_server("http://eng.sjp.ac.lk/") == "Apache/2.4.39"
	assert type(get_hosted_server("http://eng.sjp.ac.lk/")) == str


def test_get_hosted_OS():
	assert get_hosted_OS("http://eng.pdn.ac.lk") == "FreeBSD"
	assert type(get_hosted_OS("http://eng.pdn.ac.lk")) == str

	assert get_hosted_OS("https://arts.pdn.ac.lk/ ") == "FreeBSD"
	assert type(get_hosted_OS("https://arts.pdn.ac.lk/ ")) == str

	assert get_hosted_OS("http://www.eng.ruh.ac.lk/") == "Ubuntu"
	assert type(get_hosted_OS("http://www.eng.ruh.ac.lk/")) == str

	assert get_hosted_OS("http://www.jfn.ac.lk/") == "CentOS"
	assert type(get_hosted_OS("http://www.jfn.ac.lk/")) == str

	assert get_hosted_OS("http://eng.sjp.ac.lk/") == "Unix"
	assert type(get_hosted_OS("http://eng.sjp.ac.lk/")) == str


def test_is_http_streaming():
	assert is_http_streaming("https://www.apple.com/") == False
	assert type(is_http_streaming("https://www.apple.com/")) == bool

	assert is_http_streaming("http://eng.pdn.ac.lk") == True
	assert type(is_http_streaming("http://eng.pdn.ac.lk")) == bool

	assert is_http_streaming("https://docs.python.org/3/") == False
	assert type(is_http_streaming("https://docs.python.org/3/")) == bool

	assert is_http_streaming("https://docs.oracle.com/en/java/") == False
	assert type(is_http_streaming("https://docs.oracle.com/en/java/")) == bool

	assert is_http_streaming("https://sci.pdn.ac.lk/") == True
	assert type(is_http_streaming("https://sci.pdn.ac.lk/")) == bool


def test_is_valid_url():
	assert is_valid_url("http://eng.pdn.ac.lk") == "Valid"
	assert type(is_valid_url("http://eng.pdn.ac.lk")) == str
	
	assert is_valid_url("http://eng.pdn.ac.lk/unknown") == "Invalid:HTTP Error 404: Not Found"
	assert type(is_valid_url("http://eng.pdn.ac.lk/unknown")) == str
	
	assert is_valid_url("http://unknown.pdn.ac.lk") == "Invalid:<urlopen error [Errno -2] Name or service not known>"
	assert type(is_valid_url("http://unknown.pdn.ac.lk")) == str


def test_read_response():
	assert type(read_response("https://www.apple.com/")) == bytes
	utf8_decoder = codecs.getincrementaldecoder('utf8')()
	assert utf8_decoder.decode(read_response("https://www.apple.com/")) == read_response("https://www.apple.com/").decode("UTF-8")


def test_decode_response_body():
	assert type(decode_response_body(read_response("https://www.apple.com/"))) == str
	utf8_encoder = codecs.getincrementalencoder('utf8')()
	assert utf8_encoder.encode(decode_response_body(read_response("https://www.apple.com/"))) == read_response("https://www.apple.com/")