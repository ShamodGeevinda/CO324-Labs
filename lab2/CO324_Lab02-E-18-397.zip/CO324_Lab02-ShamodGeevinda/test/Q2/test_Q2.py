import sys
from urllib import request
from urllib.parse import unquote

sys.path.append('./src/Q2')

from Q2_lab02 import *

def test_add_url_parameters():
	url = add_url_parameters()
	assert ("format" in url) == True
	assert ("pretty" in url) == True
	with request.urlopen(url) as query:
		headers = query.headers.items()
		headers = {x[0].lower(): x[1].lower() for x in headers}
		assert headers["content-type"] == "application/x-javascript"


def test_search_name_in_sinhala_or_tamil():
	body, url = search_name_in_sinhala_or_tamil()
	name = unquote(url.split("=")[1])
	assert type(url) == str
	assert type(body) == str
	assert name in body