# CO324 Lab 2: HTTP Clients

## Objective
Use command line tools to make HTTP requests to various APIs. At the end of the lab you should be able to
* Use the Python urllib module to make HTTP client requests.
* Understand the difference between various HTTP request methods (verbs).
* Be able to interpret HTTP responses and status codes.
* Awareness of common HTTP headers. 


## Preparation
Install Python version 3.7 or newer on your computer. You may use whichever IDE or editor that you prefer. You will need a functioning Internet connection to do the exercises.


## Instructions
* Use only python **urllib** module to make HTTP requests. **DO NOT use any other python module to make HTTP requests.**
* Use only the standard built-in modules in Python to complete these exercises.
* Put the solutions to coding exercises for the files in `src/` directory.
* **Put your E Number as a comment** in top of each source file.
* **DO NOT** change any code in `test/` directory.


## References
* [HTTP Overview](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview)
* [request python library](https://pymotw.com/3/urllib.request/index.html)
* [URL encoding - python](https://www.urlencoder.io/python/)


## Exercises

Exercises can be found in each Question folder in the `src/`.
