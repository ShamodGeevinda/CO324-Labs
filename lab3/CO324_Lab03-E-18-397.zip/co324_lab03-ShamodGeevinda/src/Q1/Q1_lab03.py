# E/18/397
import requests
import json
from typing import Dict

def get_github_api_endpoints() -> Dict:
	"""Return the JSON output of available end points"""
	return requests.get('https://api.github.com').json()
	


def get_github_profile_info(username:str) -> Dict:
	"""Return the JSON output of github profile info"""
	github_user_url = " https://api.github.com/users/"+username
	return requests.get(github_user_url).json()



def get_github_max_ratelimit() -> int:
	"""Return max unauthenticated requests to GitHub API per hour"""
	response = requests.get('https://api.github.com')
	return int(response.headers['X-RateLimit-Limit'])
	


def get_headers_without_session() -> Dict:
	"""Returns the HTTP headers when a session is not used"""
	with requests.get("https://api.github.com") as response:
		return dict(response.headers)


def get_headers_with_session() -> Dict:
	"""Returns the HTTP headers when a session is used"""
	with requests.Session() as session:
		session.headers['Authorization'] = 'token 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' 
		response = session.get("https://api.github.com")
		return dict(response.headers)
		


def get_github_username() -> str:
	with requests.Session() as session:
		session.headers['Authorization'] = 'token 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'
		response = session.get("https://api.github.com/user")
		json = response.json()
		return json['login']

    
def create_repo(repo_data:Dict):
	"""
		1. Create a session
		2. Make a POST request to the given GitHub API endpoint to create a repo
		3. Return the HTTP response
	"""
	with requests.Session() as session:
		session.headers['Authorization'] = 'Bearer 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'
		url = 'https://api.github.com/user/repos'
		response = session.post(url, json = repo_data)
		return response
		# session.headers['Authorization'] = 'token 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'
		# token = 'token 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'
		# session.auth = (get_github_username(),token)
		# repoURL = "https://api.github.com/user/repos"
		# login = session.post(repoURL, data=json.dumps(repo_data))
		# return login

		# repo = 'some_repo'
		# description = 'Created with api'

		# payload = {'name': repo, 'description': description, 'auto_init': 'true'}
	# 	session.headers['Authorization'] = 'token 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'
	# 	user = get_github_username()
		
	# 	token = "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"
	# 	session.auth = (get_github_username(), 'token ' + token)
		
	# 	headerss = {"Authorization" :  token, 
	# 	"Accept": "application/vnd.github.v3+json",
    # }
		
		# 	
	

if __name__ == '__main__':
	#Q1.a
	print(json.dumps(get_github_api_endpoints(), indent=4, sort_keys=True))
	# # Add code to test locally

	# #Q1.b
	print(json.dumps(get_github_profile_info("ShamodGeevinda"), indent=4, sort_keys=True)) # Change username
	# # # Add code to test locally

	# # #Q1.c
	print(get_github_max_ratelimit())
	# # # Add code to test locally

	# # #Q1.d
	print(json.dumps(get_headers_without_session(), indent=4, sort_keys=True))
	print(json.dumps(get_headers_with_session(), indent=4, sort_keys=True))
	# # Add code to test locally
	print(get_github_username())
	# #Q1.e
	repo_creation_response = create_repo({'name':'test', 'description':'some test repo'})
	print(repo_creation_response)
	# Add code to test locally
	




