# E/18/397
import requests
import json
from typing import List, Tuple

def get_github_superstars(organization: str) -> List[Tuple]:
	'''Sirasa superstar for Computer engineers. :)
		1. Get a list of members in the Github organization
		2. For each member, find the repo they own with the most stars.
		3. Add the repo name and the number of stars it has to a list.
		4. Return the list sorted in descending order of stars.
	'''
	with requests.Session() as session:
		session.headers['Authorization'] = 'Bearer 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'
		pageNum = 1
		githubSuperStars = {}
		while True:
			response = session.get("https://api.github.com/orgs/"+organization+"/members?page="+str(pageNum))
			if not response.json():
				break
			for member in response.json():
				reposURL = member['repos_url']
				maxStars = 0
				maxStarsRepo = ''
				for eachRepo in (session.get(reposURL).json()):
					if(eachRepo['stargazers_count'] >= maxStars):
						maxStars = eachRepo['stargazers_count']
						maxStarsRepo = eachRepo['full_name']
				githubSuperStars[maxStarsRepo] = maxStars
			pageNum += 1
	sorted_githubSuperStars = sorted(githubSuperStars.items(), key=lambda x: x[1], reverse=True)
	return sorted_githubSuperStars
	

def watch_winning_repo(repo_name: str):
	"""Returns the HTTP response after watching the winning repo"""
	with requests.Session() as session:
		token = 'Bearer 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'
		session.headers['Authorization'] =  token
		url = 'https://api.github.com/repos/'+repo_name+'/subscription'
		response = session.put(url)

	session.close()

	return response


def get_github_username() -> str:
	"""Returns the GitHub username"""
	with requests.Session() as session:
		session.headers['Authorization'] = 'token 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'
		response = session.get("https://api.github.com/user")
		json = response.json()
		return json['login']


def make_graphql_query():
	"""Returns the HTTP response after a simple GraphQL query to GitHub API"""
	with requests.Session() as session:
		session.headers["Authorization"] = 'Bearer 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'
		query_url = "https://api.github.com/graphql" 
		query_data = "{ \"query\": \"query { viewer { login }}\" } "
		query_data = json.loads(query_data)
		request = session.post(query_url, json=query_data)
		return request

if __name__ == "__main__":
	#Q2.a
	top_cepdn_repos = get_github_superstars("cepdnaclk")
	print(top_cepdn_repos)

	#Q2.b
	repo_watch_response = watch_winning_repo(get_github_superstars("cepdnaclk")[0][0])
	print(repo_watch_response)
	# # Add code to test locally

	# #Q2.c
	graphql_response = make_graphql_query()
	print(graphql_response)
	# Add code to test locally
